Copy the gmask program somewhere in your path. You can then run the csd files
in the examples directory, provided that the samples are reachable, e.g. in SSDIR.
